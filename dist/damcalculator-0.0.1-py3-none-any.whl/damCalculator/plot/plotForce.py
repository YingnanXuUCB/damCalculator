class plotGravity:
    pass
class plotUpstreamPressure:
    pass
class plotDownstreamPressure:
    pass
class plotUpliftPressure:
    pass
class plotFriction:
    pass