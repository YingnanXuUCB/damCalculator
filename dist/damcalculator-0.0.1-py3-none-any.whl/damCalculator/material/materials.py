class concrete:
    '''
    Attributes
    -----------------
    Desnsity:Density of the concrete
    '''
    def __init__(self,density):
        self.density=density
class water:
    '''
    Attributes
    ------------------
    Density:Density of the water
    '''
    def __init__(self,density):
        self.density=density
